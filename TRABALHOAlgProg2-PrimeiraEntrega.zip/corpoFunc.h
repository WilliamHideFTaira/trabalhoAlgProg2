//=======FUNÇÕES PARA COMPARTILHAR ENTRE MAIN.CPP E FUNCOES.CPP=============
void menuRecepcionista();
void menuEnfermeiro();
void menuMedico();